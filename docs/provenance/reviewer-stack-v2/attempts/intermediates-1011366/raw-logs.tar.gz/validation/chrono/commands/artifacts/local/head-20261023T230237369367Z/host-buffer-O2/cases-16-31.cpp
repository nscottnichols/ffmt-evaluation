#define HD
#include <ffmt/base.hpp>

#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <limits>
template<class T, class U> HD T bits(U v) {return __builtin_bit_cast(T, v);}


HD void execute_case(int index) {
switch (index) {
case 16: {FFMT_PRINT("{1} {0} {1}", 12, 34); break;}
case 17: {FFMT_PRINT("[{0:>{1}}]", 42, 12); break;}
case 18: {FFMT_PRINT("{:.{}f}", 1.23456789, 4); break;}
case 19: {FFMT_PRINT("{} {} {:d} {:c}", true, false, true, 65); break;}
case 20: {FFMT_PRINT("{}", 1.23456789); break;}
case 21: {FFMT_PRINT("{}", 1e15); break;}
case 22: {FFMT_PRINT("{}", 0.1f); break;}
case 23: {FFMT_PRINT("{:+#013.5f}", -1.23456789); break;}
case 24: {FFMT_PRINT("{:.2f} {:.2f}", 1.125, 1.375); break;}
case 25: {FFMT_PRINT("{:+020.3a}", -1.03125); break;}
case 26: {FFMT_PRINT("{}", bits<float>(uint32_t(1))); break;}
case 27: {FFMT_PRINT("{}", bits<double>(uint64_t(1))); break;}
case 28: {FFMT_PRINT("{:.2f}", 1e20); break;}
case 29: {FFMT_PRINT("{} {} {}", bits<double>(uint64_t(0x8000000000000000ULL)), bits<double>(uint64_t(0x7ff0000000000000ULL)), bits<double>(uint64_t(0xfff8000000000001ULL))); break;}
case 30: {FFMT_PRINT("[{:>10}]", "静夜思"); break;}
case 31: {FFMT_PRINT("[{:.3}]", "静夜思"); break;}
}
}

int main(int argc, char** argv) {
  if (argc != 2) return 2;
  std::fprintf(stderr, "FFMT_DEVICE host\n");
  execute_case(std::atoi(argv[1]));
  return 0;
}
