#define HD
#include <fmt/format.h>

#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <limits>
template<class T, class U> HD T bits(U v) {return __builtin_bit_cast(T, v);}
#include <codecvt>
#include <fmt/xchar.h>
#include <locale>

static std::string wide_utf8(const std::wstring& text) {std::wstring_convert<std::codecvt_utf8<wchar_t>> converter; return converter.to_bytes(text);}
int main(int argc, char** argv) {
  if(argc!=2) return 2;
  switch(std::atoi(argv[1])) {case 0: {auto s=fmt::format("hello {{world}} %\n"); std::fwrite(s.data(),1,s.size(),stdout); return 0;}
case 1: {auto s=fmt::format("{}", INT64_MIN); std::fwrite(s.data(),1,s.size(),stdout); return 0;}
case 2: {auto s=fmt::format("{}", UINT64_MAX); std::fwrite(s.data(),1,s.size(),stdout); return 0;}
case 3: {auto s=fmt::format("[{:.3s}] [{:>10s}]", "abcdef", "hello"); std::fwrite(s.data(),1,s.size(),stdout); return 0;}
case 4: {auto s=fmt::format("no trailing newline"); std::fwrite(s.data(),1,s.size(),stdout); return 0;}
case 5: {auto s=fmt::format(""); std::fwrite(s.data(),1,s.size(),stdout); return 0;}
case 6: {auto s=fmt::format("a{}b", char(0)); std::fwrite(s.data(),1,s.size(),stdout); return 0;}
case 7: {auto s=fmt::format("Test 1\n# skipped: not metadata\n"); std::fwrite(s.data(),1,s.size(),stdout); return 0;}
case 8: {auto s=fmt::format("{:d}", 4000000000u); std::fwrite(s.data(),1,s.size(),stdout); return 0;}
case 9: {auto s=fmt::format("{:#010x}", -42); std::fwrite(s.data(),1,s.size(),stdout); return 0;}
case 10: {auto s=fmt::format("{:b}", UINT64_MAX); std::fwrite(s.data(),1,s.size(),stdout); return 0;}
case 11: {auto s=fmt::format("{:#x} {:#o} {:#b}", 0u, 0u, 0u); std::fwrite(s.data(),1,s.size(),stdout); return 0;}
case 12: {auto s=fmt::format("[{:>05}] [{:<05}]", 42, -42); std::fwrite(s.data(),1,s.size(),stdout); return 0;}
case 13: {auto s=fmt::format("[{:*^15}]", -42); std::fwrite(s.data(),1,s.size(),stdout); return 0;}
case 14: {auto s=fmt::format("{1} {0} {1}", 12, 34); std::fwrite(s.data(),1,s.size(),stdout); return 0;}
case 15: {auto s=fmt::format("[{0:>{1}}]", 42, 12); std::fwrite(s.data(),1,s.size(),stdout); return 0;}
case 16: {auto s=fmt::format("{:.{}f}", 1.23456789, 4); std::fwrite(s.data(),1,s.size(),stdout); return 0;}
case 17: {auto s=fmt::format("{} {} {:d} {:c}", true, false, true, 65); std::fwrite(s.data(),1,s.size(),stdout); return 0;}
case 18: {auto s=fmt::format("{}", 1.23456789); std::fwrite(s.data(),1,s.size(),stdout); return 0;}
case 19: {auto s=fmt::format("{}", 1e15); std::fwrite(s.data(),1,s.size(),stdout); return 0;}
case 20: {auto s=fmt::format("{}", 0.1f); std::fwrite(s.data(),1,s.size(),stdout); return 0;}
case 21: {auto s=fmt::format("{:+#013.5f}", -1.23456789); std::fwrite(s.data(),1,s.size(),stdout); return 0;}
case 22: {auto s=fmt::format("{:.2f} {:.2f}", 1.125, 1.375); std::fwrite(s.data(),1,s.size(),stdout); return 0;}
case 23: {auto s=fmt::format("{:+020.3a}", -1.03125); std::fwrite(s.data(),1,s.size(),stdout); return 0;}
case 24: {auto s=fmt::format("{}", bits<float>(uint32_t(1))); std::fwrite(s.data(),1,s.size(),stdout); return 0;}
case 25: {auto s=fmt::format("{}", bits<double>(uint64_t(1))); std::fwrite(s.data(),1,s.size(),stdout); return 0;}
case 26: {auto s=fmt::format("{:.2f}", 1e20); std::fwrite(s.data(),1,s.size(),stdout); return 0;}
case 27: {auto s=fmt::format("{} {} {}", bits<double>(uint64_t(0x8000000000000000ULL)), bits<double>(uint64_t(0x7ff0000000000000ULL)), bits<double>(uint64_t(0xfff8000000000001ULL))); std::fwrite(s.data(),1,s.size(),stdout); return 0;}
case 28: {auto s=fmt::format("[{:>10}]", "静夜思"); std::fwrite(s.data(),1,s.size(),stdout); return 0;}
case 29: {auto s=fmt::format("[{:.3}]", "静夜思"); std::fwrite(s.data(),1,s.size(),stdout); return 0;}
case 30: {auto s=fmt::format("[{:─^9}]", "é"); std::fwrite(s.data(),1,s.size(),stdout); return 0;}
case 31: {auto s=fmt::format("{:?}", "a\n\t\""); std::fwrite(s.data(),1,s.size(),stdout); return 0;}
case 32: {auto s=fmt::format("{:?}", '\n'); std::fwrite(s.data(),1,s.size(),stdout); return 0;}
case 33: {auto s=fmt::format("{}", static_cast<void*>(nullptr)); std::fwrite(s.data(),1,s.size(),stdout); return 0;}
case 34: {auto s=fmt::format("[{:300}]", 1); std::fwrite(s.data(),1,s.size(),stdout); return 0;}
case 35: {auto s=fmt::format("{:.180f}", 0.125); std::fwrite(s.data(),1,s.size(),stdout); return 0;}
case 36: {auto s=fmt::format("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"); std::fwrite(s.data(),1,s.size(),stdout); return 0;}
case 37: {auto s=fmt::format("{0}{0}{0}{0}{0}{0}{0}{0}{0}{0}{0}{0}{0}{0}{0}{0}{0}{0}{0}{0}", 1); std::fwrite(s.data(),1,s.size(),stdout); return 0;}
case 38: {auto s=fmt::format("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%{}", "%%%%%%%%%%%%"); std::fwrite(s.data(),1,s.size(),stdout); return 0;}
case 39: {auto s=fmt::format("{:300}", 1) + "\n"; std::fwrite(s.data(),1,s.size(),stdout); return 0;}
case 40: {auto s=fmt::format(fmt::runtime("{:04x}"), 42); std::fwrite(s.data(),1,s.size(),stdout); return 0;}
case 41: {auto s=wide_utf8(fmt::format(L"[{:>8}] {:.3f}", L"静夜", 1.25)); std::fwrite(s.data(),1,s.size(),stdout); return 0;}
case 42: {auto s=fmt::format("{value:04x}", fmt::arg("value", 42)); std::fwrite(s.data(),1,s.size(),stdout); return 0;}}return 2;}
