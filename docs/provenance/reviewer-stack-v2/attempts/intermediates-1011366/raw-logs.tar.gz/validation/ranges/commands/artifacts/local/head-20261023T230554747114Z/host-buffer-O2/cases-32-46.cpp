#define HD
#include <ffmt/base.hpp>

#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <limits>
template<class T, class U> HD T bits(U v) {return __builtin_bit_cast(T, v);}
#include <array>
#include <ffmt/ranges.hpp>
#include <tuple>


struct family_padding_value {int mutations;};
struct family_padding_range {
  family_padding_value values[2];
  HD family_padding_value* begin() {return values;}
  HD family_padding_value* end() {return values + 2;}
};

template<> struct ffmt::formatter<family_padding_value> : ffmt::formatter<int> {
  template<class Context>
  HD auto format(family_padding_value& value, Context& ctx) const -> decltype(ctx.out()) {
    return ffmt::formatter<int>::format(++value.mutations, ctx);
  }
};
HD void bounded_family_padding() {
  family_padding_range value{{{0}, {0}}};
  char stored[16];
  auto result = ffmt::format_to_n(stored, sizeof(stored), "{:*>20:03}", value);
  ffmt::print("buffer=<{}>|mutations={},{}|written={}|required={}|error={}",
              ffmt::string_view(stored, result.written), value.values[0].mutations,
              value.values[1].mutations, result.written, result.required, int(result.error));
}
HD void stream_left_family_padding() {
  family_padding_range value{{{0}, {0}}};
  auto result = ffmt::try_print("{:*<20:03}", value);
  ffmt::print("|mutations={},{}|written={}|required={}|error={}",
              value.values[0].mutations, value.values[1].mutations,
              result.written, result.required, int(result.error));
}

HD void execute_case(int index) {
switch (index) {
case 32: {FFMT_PRINT("{:?}", '\n'); break;}
case 33: {FFMT_PRINT("{}", static_cast<void*>(nullptr)); break;}
case 34: {FFMT_PRINT("[{:300}]", 1); break;}
case 35: {FFMT_PRINT("{:.180f}", 0.125); break;}
case 36: {FFMT_PRINT("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"); break;}
case 37: {FFMT_PRINT("{0}{0}{0}{0}{0}{0}{0}{0}{0}{0}{0}{0}{0}{0}{0}{0}{0}{0}{0}{0}", 1); break;}
case 38: {FFMT_PRINT("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%{}", "%%%%%%%%%%%%"); break;}
case 39: {FFMT_PRINTLN("{:300}", 1); break;}
case 40: {ffmt::print(ffmt::runtime("{:04x}"), 42); break;}
case 41: {ffmt::print(L"[{:>8}] {:.3f}", L"静夜", 1.25); break;}
case 42: {ffmt::print("{::03}", std::array<int,3>{1,-2,33}); break;}
case 43: {ffmt::print("{}", std::tuple<int, bool, const char*>{42, true, "a"}); break;}
case 44: {ffmt::print("{:02x}", ffmt::join(std::array<int,3>{1,2,33}, ",")); break;}
case 45: {bounded_family_padding(); break;}
case 46: {stream_left_family_padding(); break;}
}
}

int main(int argc, char** argv) {
  if (argc != 2) return 2;
  std::fprintf(stderr, "FFMT_DEVICE host\n");
  execute_case(std::atoi(argv[1]));
  return 0;
}
