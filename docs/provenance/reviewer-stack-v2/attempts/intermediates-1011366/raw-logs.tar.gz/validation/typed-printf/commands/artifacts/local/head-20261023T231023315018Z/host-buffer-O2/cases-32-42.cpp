#define HD
#include <ffmt/base.hpp>

#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <limits>
template<class T, class U> HD T bits(U v) {return __builtin_bit_cast(T, v);}
#include <ffmt/printf.hpp>

HD void execute_case(int index) {
switch (index) {
case 32: {FFMT_PRINT("{:?}", '\n'); break;}
case 33: {FFMT_PRINT("{}", static_cast<void*>(nullptr)); break;}
case 34: {FFMT_PRINT("[{:300}]", 1); break;}
case 35: {FFMT_PRINT("{:.180f}", 0.125); break;}
case 36: {FFMT_PRINT("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"); break;}
case 37: {FFMT_PRINT("{0}{0}{0}{0}{0}{0}{0}{0}{0}{0}{0}{0}{0}{0}{0}{0}{0}{0}{0}{0}", 1); break;}
case 38: {FFMT_PRINT("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%{}", "%%%%%%%%%%%%"); break;}
case 39: {FFMT_PRINTLN("{:300}", 1); break;}
case 40: {ffmt::print(ffmt::runtime("{:04x}"), 42); break;}
case 41: {ffmt::print(L"[{:>8}] {:.3f}", L"静夜", 1.25); break;}
case 42: {(void)ffmt::try_printf("%#08x %.3f", 42u, 1.25); break;}
}
}

int main(int argc, char** argv) {
  if (argc != 2) return 2;
  std::fprintf(stderr, "FFMT_DEVICE host\n");
  execute_case(std::atoi(argv[1]));
  return 0;
}
