#define HD
#include <ffmt/base.hpp>

#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <limits>
template<class T, class U> HD T bits(U v) {return __builtin_bit_cast(T, v);}


HD void execute_case(int index) {
switch (index) {
case 0: {FFMT_PRINT("hello {{world}} %\n"); break;}
case 1: {FFMT_PRINT("{}", INT64_MIN); break;}
case 2: {FFMT_PRINT("{}", UINT64_MAX); break;}
case 3: {FFMT_PRINT("[{:.3s}] [{:>10s}]", "abcdef", "hello"); break;}
case 4: {FFMT_PRINT("no trailing newline"); break;}
case 5: {FFMT_PRINT(""); break;}
case 6: {FFMT_PRINT("a{}b", char(0)); break;}
case 7: {FFMT_PRINT("Test 1\n# skipped: not metadata\n"); break;}
case 8: {FFMT_PRINT("{:d}", 4000000000u); break;}
case 9: {FFMT_PRINT("{:#010x}", -42); break;}
case 10: {FFMT_PRINT("{:b}", UINT64_MAX); break;}
case 11: {FFMT_PRINT("{:#x} {:#o} {:#b}", 0u, 0u, 0u); break;}
case 12: {FFMT_PRINT("[{:>05}] [{:<05}]", 42, -42); break;}
case 13: {FFMT_PRINT("[{:*^15}]", -42); break;}
case 14: {FFMT_PRINT("{1} {0} {1}", 12, 34); break;}
case 15: {FFMT_PRINT("[{0:>{1}}]", 42, 12); break;}
}
}

int main(int argc, char** argv) {
  if (argc != 2) return 2;
  std::fprintf(stderr, "FFMT_DEVICE host\n");
  execute_case(std::atoi(argv[1]));
  return 0;
}
