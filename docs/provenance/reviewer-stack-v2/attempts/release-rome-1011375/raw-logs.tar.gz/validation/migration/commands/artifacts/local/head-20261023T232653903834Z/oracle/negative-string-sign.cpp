#define HD
#include <fmt/format.h>

#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <limits>
template<class T, class U> HD T bits(U v) {return __builtin_bit_cast(T, v);}


int main(int argc, char** argv) {
  if(argc!=2) return 2;
  switch(std::atoi(argv[1])) {case 0: {auto s=fmt::format("{:+}", "text"); std::fwrite(s.data(),1,s.size(),stdout); return 0;}}return 2;}
