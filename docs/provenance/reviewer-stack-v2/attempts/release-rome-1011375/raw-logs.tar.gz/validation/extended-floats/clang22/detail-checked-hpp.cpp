#include <ffmt/detail/checked.hpp>
int main() { return 0; }
