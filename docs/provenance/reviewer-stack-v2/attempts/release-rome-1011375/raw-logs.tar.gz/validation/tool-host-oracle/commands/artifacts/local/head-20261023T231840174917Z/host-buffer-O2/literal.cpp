#define HD
#include <ffmt/base.hpp>

#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <limits>
template<class T, class U> HD T bits(U v) {return __builtin_bit_cast(T, v);}


HD void execute_case(int index) {
switch (index) {
case 0: {FFMT_PRINT("hello {{world}} %\n"); break;}
}
}

int main(int argc, char** argv) {
  if (argc != 2) return 2;
  std::fprintf(stderr, "FFMT_DEVICE host\n");
  execute_case(std::atoi(argv[1]));
  return 0;
}
