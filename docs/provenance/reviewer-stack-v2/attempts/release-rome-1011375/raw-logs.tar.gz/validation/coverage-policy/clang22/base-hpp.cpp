#include <ffmt/base.hpp>
int main() { return 0; }
