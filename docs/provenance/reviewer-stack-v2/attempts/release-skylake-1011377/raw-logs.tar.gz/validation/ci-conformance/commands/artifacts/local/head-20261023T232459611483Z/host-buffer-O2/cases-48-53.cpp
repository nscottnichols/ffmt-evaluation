#define HD
#include <ffmt/base.hpp>

#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <limits>
template<class T, class U> HD T bits(U v) {return __builtin_bit_cast(T, v);}
#include <array>
#include <complex>
#include <ffmt/color.hpp>
#include <ffmt/ranges.hpp>
#include <ffmt/std.hpp>
#include <optional>


struct family_padding_value {int mutations;};
struct family_padding_range {
  family_padding_value values[2];
  HD family_padding_value* begin() {return values;}
  HD family_padding_value* end() {return values + 2;}
};

template<> struct ffmt::formatter<family_padding_value> : ffmt::formatter<int> {
  template<class Context>
  HD auto format(family_padding_value& value, Context& ctx) const -> decltype(ctx.out()) {
    return ffmt::formatter<int>::format(++value.mutations, ctx);
  }
};
HD void bounded_family_padding() {
  family_padding_range value{{{0}, {0}}};
  char stored[16];
  auto result = ffmt::format_to_n(stored, sizeof(stored), "{:*>20:03}", value);
  ffmt::print("buffer=<{}>|mutations={},{}|written={}|required={}|error={}",
              ffmt::string_view(stored, result.written), value.values[0].mutations,
              value.values[1].mutations, result.written, result.required, int(result.error));
}
HD void stream_left_family_padding() {
  family_padding_range value{{{0}, {0}}};
  auto result = ffmt::try_print("{:*<20:03}", value);
  ffmt::print("|mutations={},{}|written={}|required={}|error={}",
              value.values[0].mutations, value.values[1].mutations,
              result.written, result.required, int(result.error));
}

HD void execute_case(int index) {
switch (index) {
case 48: {ffmt::print("{:02x}", ffmt::join(std::array<int,3>{1,2,33}, ",")); break;}
case 49: {bounded_family_padding(); break;}
case 50: {stream_left_family_padding(); break;}
case 51: {ffmt::print("{}", std::optional<int>{42}); break;}
case 52: {ffmt::print("{:.3f}", std::complex<double>{1,-2.2}); break;}
case 53: {ffmt::print("{}", ffmt::styled(42, ffmt::fg(ffmt::rgb(255,20,30)) | ffmt::emphasis::bold)); break;}
}
}

int main(int argc, char** argv) {
  if (argc != 2) return 2;
  std::fprintf(stderr, "FFMT_DEVICE host\n");
  execute_case(std::atoi(argv[1]));
  return 0;
}
